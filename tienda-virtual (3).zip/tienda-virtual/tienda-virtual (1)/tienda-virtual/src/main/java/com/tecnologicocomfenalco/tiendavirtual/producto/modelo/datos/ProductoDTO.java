package com.tecnologicocomfenalco.tiendavirtual.producto.modelo.dtos;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class ProductoDTO {
    private String sku;
    private String name;
    private int quantity;
    private float price;
    private List<CategoriaDTO> categories;
}


