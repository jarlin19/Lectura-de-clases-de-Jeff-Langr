package com.tecnologicocomfenalco.tiendavirtual.producto.modelo.entidades;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class categoria {
    private int id;
    private String code;
    private String name;
}
