package com.tecnologicocomfenalco.tiendavirtual.producto.servicios.impl;

import com.tecnologicocomfenalco.tiendavirtual.producto.modelo.dtos.CategoriaDTO;
import com.tecnologicocomfenalco.tiendavirtual.producto.servicios.CategoriaService;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class CategoryServiceImpl implements CategoriaService {
    @Override
    public void create(CategoriaDTO category) {
        System.out.println("Crear");
    }

    @Override
    public List<CategoriaDTO> findAll() {
        List<CategoriaDTO> list= Arrays
                .asList(
                        new CategoriaDTO("001","Tecnologia"),
                        new CategoriaDTO("002","Comida"),
                        new CategoriaDTO("003","Vestuario"),
                        new CategoriaDTO("004","Jugueteria"),
                        new CategoriaDTO("005","Otros")
                        );
        return list;
    }
}
