package com.tecnologicocomfenalco.tiendavirtual.producto.servicios.impl;

import com.tecnologicocomfenalco.tiendavirtual.producto.modelo.dtos.ProductoDTO;
import com.tecnologicocomfenalco.tiendavirtual.producto.servicios.ProductoService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductoService {
    @Override
    public List<ProductoDTO> findAll() {
        return List.of();
    }
}
