package com.tecnologicocomfenalco.tiendavirtual.producto.controlador;

import com.tecnologicocomfenalco.tiendavirtual.producto.modelo.dtos.CategoriaDTO;
import com.tecnologicocomfenalco.tiendavirtual.producto.servicios.CategoriaService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class categoriacontrolador {

    private final CategoriaService categoryService;

    public categoriacontrolador(CategoriaService categoryService) {
        this.categoryService = categoryService;
    }

    @PostMapping("category")
    public void create(CategoriaDTO categoryDTO){
        categoryService.create(categoryDTO);
    }

    @GetMapping("category")
    public List<CategoriaDTO> findAll(){
        return categoryService.findAll();
    }
}
