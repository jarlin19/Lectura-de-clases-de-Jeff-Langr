package com.tecnologicocomfenalco.tiendavirtual.producto.servicios;

import com.tecnologicocomfenalco.tiendavirtual.producto.modelo.dtos.CategoriaDTO;

import java.util.List;

public interface CategoriaService {
    void create(CategoriaDTO category);
    List<CategoriaDTO> findAll();
}
