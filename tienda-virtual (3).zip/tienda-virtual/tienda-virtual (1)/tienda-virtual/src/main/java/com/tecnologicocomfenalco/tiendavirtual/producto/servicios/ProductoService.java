package com.tecnologicocomfenalco.tiendavirtual.producto.servicios;

import com.tecnologicocomfenalco.tiendavirtual.producto.modelo.dtos.ProductoDTO;

import java.util.List;

public interface ProductoService {
    List<ProductoDTO> findAll();
}
