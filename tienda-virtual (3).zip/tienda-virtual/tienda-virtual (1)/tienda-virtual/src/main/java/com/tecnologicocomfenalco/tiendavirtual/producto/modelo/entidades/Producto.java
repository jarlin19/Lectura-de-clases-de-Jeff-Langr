package com.tecnologicocomfenalco.tiendavirtual.producto.modelo.entidades;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class Producto {
    private int id;
    private String sku;
    private String name;
    private int quantity;
    private float price;
    private List<categoria> categories;
}


