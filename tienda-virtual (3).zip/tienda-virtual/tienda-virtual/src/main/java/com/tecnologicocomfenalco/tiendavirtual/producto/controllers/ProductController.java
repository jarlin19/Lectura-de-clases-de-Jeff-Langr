package com.tecnologicocomfenalco.tiendavirtual.producto.controllers;

public class ProductController {
}
