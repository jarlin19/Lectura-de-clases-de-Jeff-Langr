package com.tecnologicocomfenalco.tiendavirtual.producto.services.impl;

import com.tecnologicocomfenalco.tiendavirtual.producto.models.dtos.CategoryDTO;
import com.tecnologicocomfenalco.tiendavirtual.producto.services.CategoryService;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class CategoryServiceImpl implements CategoryService {
    @Override
    public void create(CategoryDTO category) {
        System.out.println("Crear");
    }

    @Override
    public List<CategoryDTO> findAll() {
        List<CategoryDTO> list= Arrays
                .asList(
                        new CategoryDTO("001","Tecnologia"),
                        new CategoryDTO("002","Comida"),
                        new CategoryDTO("003","Vestuario"),
                        new CategoryDTO("004","Jugueteria"),
                        new CategoryDTO("005","Otros")
                        );
        return list;
    }
}
