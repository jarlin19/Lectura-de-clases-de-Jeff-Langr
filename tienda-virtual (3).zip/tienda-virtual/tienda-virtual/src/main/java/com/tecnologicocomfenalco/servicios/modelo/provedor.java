package com.tecnologicocomfenalco.servicios.modelo;

public class provedor{

}
