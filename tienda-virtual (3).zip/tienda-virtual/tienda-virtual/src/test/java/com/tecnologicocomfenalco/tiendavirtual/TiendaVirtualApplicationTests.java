package com.tecnologicocomfenalco.tiendavirtual;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaVirtualApplicationTests {

	@Test
	void contextLoads() {
	}

}
